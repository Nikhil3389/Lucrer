module.exports = {
  "semi": true,
  "tabSize": 2,
  "tabWidth": 2,
  "singleQuote": true,
  "trailingComma": "es5",
  "arrowParens": "always",
  "bracketSpacing": true,
  "jsxSingleQuote": true,
  "useTabs": false,
  "printWidth": 100,
  "endOfLine": "auto"
};
